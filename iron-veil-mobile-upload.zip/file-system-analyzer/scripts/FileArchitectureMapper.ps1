# Advanced File Architecture Mapper
# Generates comprehensive file structure analysis with detailed metadata
# Uses proven PowerShell methods - tested and verified

param(
    [Parameter(Mandatory=$false)]
    [string]$TargetPath = "iron-veil-sbg-main",
    
    [Parameter(Mandatory=$false)]
    [string]$OutputFormat = "All",  # All, Tree, JSON, CSV, HTML
    
    [Parameter(Mandatory=$false)]
    [string]$OutputDirectory = "architecture_reports",
    
    [Parameter(Mandatory=$false)]
    [switch]$IncludeHash = $true,
    
    [Parameter(Mandatory=$false)]
    [switch]$IncludeMetadata = $true
)

# Ensure output directory exists
if (-not (Test-Path $OutputDirectory)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
}

Write-Host "=== Advanced File Architecture Mapper ===" -ForegroundColor Cyan
Write-Host "Target: $TargetPath" -ForegroundColor Yellow
Write-Host "Output: $OutputDirectory" -ForegroundColor Yellow
Write-Host ""

if (-not (Test-Path $TargetPath)) {
    Write-Host "Error: Target path '$TargetPath' does not exist!" -ForegroundColor Red
    exit 1
}

# Function to get file tree structure
function Get-FileTree {
    param(
        [string]$Path,
        [string]$Prefix = "",
        [bool]$IsLast = $true
    )
    
    $items = @()
    $files = Get-ChildItem -Path $Path -File -ErrorAction SilentlyContinue | Sort-Object Name
    $dirs = Get-ChildItem -Path $Path -Directory -ErrorAction SilentlyContinue | Sort-Object Name
    
    $allItems = @()
    foreach ($dir in $dirs) {
        $allItems += [PSCustomObject]@{Type='Directory'; Name=$dir.Name; FullPath=$dir.FullName; Item=$dir}
    }
    foreach ($file in $files) {
        $allItems += [PSCustomObject]@{Type='File'; Name=$file.Name; FullPath=$file.FullName; Item=$file}
    }
    
    $totalItems = $allItems.Count
    $currentIndex = 0
    
    foreach ($item in $allItems) {
        $currentIndex++
        $isLastItem = ($currentIndex -eq $totalItems)
        
        $connector = if ($isLastItem) { "+-- " } else { "+-- " }
        $line = $Prefix + $connector + $item.Name
        
        if ($item.Type -eq 'File') {
            $fileInfo = $item.Item
            $size = $fileInfo.Length
            $sizeFormatted = Format-FileSize -Bytes $size
            $line += " ($sizeFormatted)"
            
            if ($IncludeHash) {
                try {
                    $hash = (Get-FileHash -Path $fileInfo.FullName -Algorithm SHA256 -ErrorAction Stop).Hash.ToLower()
                    $line += " [SHA256: $($hash.Substring(0,8))...]"
                } catch {
                    $line += " [Hash: Error]"
                }
            }
        }
        
        $items += $line
        
        if ($item.Type -eq 'Directory') {
            $newPrefix = $Prefix + $(if ($isLastItem) { "    " } else { "|   " })
            $subItems = Get-FileTree -Path $item.FullPath -Prefix $newPrefix -IsLast $isLastItem
            $items += $subItems
        }
    }
    
    return $items
}

# Function to format file size
function Format-FileSize {
    param([long]$Bytes)
    
    if ($Bytes -lt 1KB) { return "$Bytes B" }
    elseif ($Bytes -lt 1MB) { return "{0:N2} KB" -f ($Bytes / 1KB) }
    elseif ($Bytes -lt 1GB) { return "{0:N2} MB" -f ($Bytes / 1MB) }
    else { return "{0:N2} GB" -f ($Bytes / 1GB) }
}

# Function to get detailed file information
function Get-FileDetails {
    param([System.IO.FileInfo]$File)
    
    $details = @{
        Name = $File.Name
        FullPath = $File.FullName
        RelativePath = $File.FullName.Replace((Resolve-Path $TargetPath).Path + "\", "").Replace("\", "/")
        Size = $File.Length
        SizeFormatted = Format-FileSize -Bytes $File.Length
        Extension = $File.Extension
        LastWriteTime = $File.LastWriteTime
        LastAccessTime = $File.LastAccessTime
        CreationTime = $File.CreationTime
        Attributes = $File.Attributes.ToString()
    }
    
    if ($IncludeHash) {
        try {
            $details.SHA256 = (Get-FileHash -Path $File.FullName -Algorithm SHA256 -ErrorAction Stop).Hash.ToLower()
        } catch {
            $details.SHA256 = "Error: $($_.Exception.Message)"
        }
    }
    
    return $details
}

# Function to get directory statistics
function Get-DirectoryStats {
    param([string]$Path)
    
    $files = Get-ChildItem -Path $Path -Recurse -File -ErrorAction SilentlyContinue
    $dirs = Get-ChildItem -Path $Path -Recurse -Directory -ErrorAction SilentlyContinue
    
    $totalSize = ($files | Measure-Object -Property Length -Sum).Sum
    $extensions = $files | Group-Object Extension | Sort-Object Count -Descending
    
    return @{
        TotalFiles = $files.Count
        TotalDirectories = $dirs.Count
        TotalSize = $totalSize
        TotalSizeFormatted = Format-FileSize -Bytes $totalSize
        FileExtensions = $extensions | ForEach-Object {
            @{
                Extension = if ($_.Name) { $_.Name } else { "(no extension)" }
                Count = $_.Count
                TotalSize = ($_.Group | Measure-Object -Property Length -Sum).Sum
            }
        }
    }
}

# Collect all file information
Write-Host "Scanning directory structure..." -ForegroundColor Yellow
$allFiles = Get-ChildItem -Path $TargetPath -Recurse -File -ErrorAction SilentlyContinue
$fileData = @()

foreach ($file in $allFiles) {
    $relativePath = $file.FullName.Replace((Resolve-Path $TargetPath).Path + "\", "").Replace("\", "/")
    Write-Host "  Processing: $relativePath" -ForegroundColor Gray
    
    $fileInfo = Get-FileDetails -File $file
    $fileData += $fileInfo
}

Write-Host ""
Write-Host "Generating statistics..." -ForegroundColor Yellow
$stats = Get-DirectoryStats -Path $TargetPath

# Generate tree structure
Write-Host "Generating tree structure..." -ForegroundColor Yellow
$tree = Get-FileTree -Path $TargetPath
$treeOutput = @"
=== File Architecture Tree ===
$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Target: $TargetPath

$($tree -join "`n")

=== Statistics ===
Total Files: $($stats.TotalFiles)
Total Directories: $($stats.TotalDirectories)
Total Size: $($stats.TotalSizeFormatted)

=== File Types ===
$($stats.FileExtensions | ForEach-Object {
    "$($_.Extension): $($_.Count) files ($(Format-FileSize -Bytes $_.TotalSize))"
} | Out-String)
"@

# Generate JSON output
$jsonData = @{
    Generated = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
    TargetPath = (Resolve-Path $TargetPath).Path
    Statistics = $stats
    Files = $fileData
}

$jsonOutput = $jsonData | ConvertTo-Json -Depth 10

# Generate CSV output
$csvData = $fileData | Select-Object Name, RelativePath, Size, SizeFormatted, Extension, SHA256, LastWriteTime
$csvOutput = $csvData | ConvertTo-Csv -NoTypeInformation

# Generate HTML report
$htmlOutput = @"
<!DOCTYPE html>
<html>
<head>
    <title>File Architecture Report - $(Get-Date -Format 'yyyy-MM-dd')</title>
    <style>
        body { font-family: 'Consolas', 'Courier New', monospace; margin: 20px; background: #1e1e1e; color: #d4d4d4; }
        h1 { color: #4ec9b0; }
        h2 { color: #569cd6; margin-top: 30px; }
        pre { background: #252526; padding: 15px; border-radius: 5px; overflow-x: auto; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #3e3e42; padding: 8px; text-align: left; }
        th { background: #2d2d30; color: #4ec9b0; }
        tr:nth-child(even) { background: #252526; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
        .stat-box { background: #2d2d30; padding: 15px; border-radius: 5px; }
        .stat-value { font-size: 24px; color: #4ec9b0; font-weight: bold; }
        .stat-label { color: #858585; font-size: 12px; }
    </style>
</head>
<body>
    <h1>File Architecture Report</h1>
    <p><strong>Generated:</strong> $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")</p>
    <p><strong>Target Path:</strong> $TargetPath</p>
    
    <div class="stats">
        <div class="stat-box">
            <div class="stat-value">$($stats.TotalFiles)</div>
            <div class="stat-label">Total Files</div>
        </div>
        <div class="stat-box">
            <div class="stat-value">$($stats.TotalDirectories)</div>
            <div class="stat-label">Total Directories</div>
        </div>
        <div class="stat-box">
            <div class="stat-value">$($stats.TotalSizeFormatted)</div>
            <div class="stat-label">Total Size</div>
        </div>
    </div>
    
    <h2>Directory Tree</h2>
    <pre>$($tree -join "`n")</pre>
    
    <h2>File Details</h2>
    <table>
        <tr>
            <th>Name</th>
            <th>Path</th>
            <th>Size</th>
            <th>Extension</th>
            <th>SHA256</th>
            <th>Last Modified</th>
        </tr>
        $($fileData | ForEach-Object {
            "<tr>
                <td>$($_.Name)</td>
                <td>$($_.RelativePath)</td>
                <td>$($_.SizeFormatted)</td>
                <td>$($_.Extension)</td>
                <td style='font-size: 10px;'>$($_.SHA256)</td>
                <td>$($_.LastWriteTime)</td>
            </tr>"
        } | Out-String)
    </table>
    
    <h2>File Type Distribution</h2>
    <table>
        <tr>
            <th>Extension</th>
            <th>Count</th>
            <th>Total Size</th>
        </tr>
        $($stats.FileExtensions | ForEach-Object {
            "<tr>
                <td>$($_.Extension)</td>
                <td>$($_.Count)</td>
                <td>$(Format-FileSize -Bytes $_.TotalSize)</td>
            </tr>"
        } | Out-String)
    </table>
</body>
</html>
"@

# Write outputs based on format
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"

if ($OutputFormat -eq "All" -or $OutputFormat -eq "Tree") {
    $treeFile = Join-Path $OutputDirectory "architecture_tree_$timestamp.txt"
    $treeOutput | Out-File -FilePath $treeFile -Encoding UTF8
    Write-Host "Tree structure saved to: $treeFile" -ForegroundColor Green
}

if ($OutputFormat -eq "All" -or $OutputFormat -eq "JSON") {
    $jsonFile = Join-Path $OutputDirectory "architecture_manifest_$timestamp.json"
    $jsonOutput | Out-File -FilePath $jsonFile -Encoding UTF8
    Write-Host "JSON manifest saved to: $jsonFile" -ForegroundColor Green
}

if ($OutputFormat -eq "All" -or $OutputFormat -eq "CSV") {
    $csvFile = Join-Path $OutputDirectory "architecture_inventory_$timestamp.csv"
    $csvOutput | Out-File -FilePath $csvFile -Encoding UTF8
    Write-Host "CSV inventory saved to: $csvFile" -ForegroundColor Green
}

if ($OutputFormat -eq "All" -or $OutputFormat -eq "HTML") {
    $htmlFile = Join-Path $OutputDirectory "architecture_report_$timestamp.html"
    $htmlOutput | Out-File -FilePath $htmlFile -Encoding UTF8
    Write-Host "HTML report saved to: $htmlFile" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== Mapping Complete ===" -ForegroundColor Cyan
Write-Host "Files processed: $($fileData.Count)" -ForegroundColor Green
Write-Host "Total size: $($stats.TotalSizeFormatted)" -ForegroundColor Green

