# Master File System Analyzer
# Comprehensive tool that combines architecture mapping, integrity verification, and manifest generation
# All methods tested and verified to work

param(
    [Parameter(Mandatory=$false)]
    [string]$TargetPath = "..\iron-veil-sbg-main",
    
    [Parameter(Mandatory=$false)]
    [string]$InventoryFile = "..\data\Repository_file_inventory.csv",
    
    [Parameter(Mandatory=$false)]
    [string]$OutputDirectory = "..\reports",
    
    [Parameter(Mandatory=$false)]
    [switch]$RunArchitectureMapping = $true,
    
    [Parameter(Mandatory=$false)]
    [switch]$RunIntegrityVerification = $true,
    
    [Parameter(Mandatory=$false)]
    [switch]$RunManifestGeneration = $true,
    
    [Parameter(Mandatory=$false)]
    [switch]$IncludeHash = $true
)

$startTime = Get-Date

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Master File System Analyzer" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Target: $TargetPath" -ForegroundColor Yellow
Write-Host "Started: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Yellow
Write-Host ""

# Ensure output directory exists
if (-not (Test-Path $OutputDirectory)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
}

$results = @{
    StartTime = $startTime
    TargetPath = $TargetPath
    InventoryFile = $InventoryFile
    Steps = @()
}

# Step 1: Architecture Mapping
if ($RunArchitectureMapping) {
    Write-Host "=== Step 1: Architecture Mapping ===" -ForegroundColor Cyan
    try {
        $mapStart = Get-Date
        & "$PSScriptRoot\FileArchitectureMapper.ps1" -TargetPath $TargetPath -OutputFormat "All" -OutputDirectory $OutputDirectory -IncludeHash:$IncludeHash
        $mapEnd = Get-Date
        $results.Steps += @{
            Name = "Architecture Mapping"
            Status = "Success"
            Duration = ($mapEnd - $mapStart).TotalSeconds
        }
        Write-Host "Architecture mapping completed successfully" -ForegroundColor Green
    } catch {
        Write-Host "Architecture mapping failed: $($_.Exception.Message)" -ForegroundColor Red
        $results.Steps += @{
            Name = "Architecture Mapping"
            Status = "Failed"
            Error = $_.Exception.Message
        }
    }
    Write-Host ""
}

# Step 2: Integrity Verification
if ($RunIntegrityVerification -and (Test-Path $InventoryFile)) {
    Write-Host "=== Step 2: Integrity Verification ===" -ForegroundColor Cyan
    try {
        $verifyStart = Get-Date
        & "$PSScriptRoot\AdvancedIntegrityVerifier.ps1" -InventoryFile $InventoryFile -BasePath ".." -OutputDirectory $OutputDirectory -GenerateReport
        $verifyEnd = Get-Date
        $results.Steps += @{
            Name = "Integrity Verification"
            Status = "Success"
            Duration = ($verifyEnd - $verifyStart).TotalSeconds
        }
        Write-Host "Integrity verification completed successfully" -ForegroundColor Green
    } catch {
        Write-Host "Integrity verification failed: $($_.Exception.Message)" -ForegroundColor Red
        $results.Steps += @{
            Name = "Integrity Verification"
            Status = "Failed"
            Error = $_.Exception.Message
        }
    }
    Write-Host ""
} elseif ($RunIntegrityVerification) {
    Write-Host "=== Step 2: Integrity Verification ===" -ForegroundColor Cyan
    Write-Host "Skipped: Inventory file not found: $InventoryFile" -ForegroundColor Yellow
    Write-Host ""
}

# Step 3: Manifest Generation
if ($RunManifestGeneration) {
    Write-Host "=== Step 3: Manifest Generation ===" -ForegroundColor Cyan
    try {
        $manifestStart = Get-Date
        $manifestFile = Join-Path $OutputDirectory "comprehensive_manifest.json"
        & "$PSScriptRoot\ManifestGenerator.ps1" -TargetPath $TargetPath -OutputFile $manifestFile -IncludeHash:$IncludeHash -GenerateCSV
        $manifestEnd = Get-Date
        $results.Steps += @{
            Name = "Manifest Generation"
            Status = "Success"
            Duration = ($manifestEnd - $manifestStart).TotalSeconds
            OutputFile = $manifestFile
        }
        Write-Host "Manifest generation completed successfully" -ForegroundColor Green
    } catch {
        Write-Host "Manifest generation failed: $($_.Exception.Message)" -ForegroundColor Red
        $results.Steps += @{
            Name = "Manifest Generation"
            Status = "Failed"
            Error = $_.Exception.Message
        }
    }
    Write-Host ""
}

$endTime = Get-Date
$totalDuration = $endTime - $startTime
$results.EndTime = $endTime
$results.TotalDuration = $totalDuration.TotalSeconds

# Generate summary report
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Analysis Summary" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Duration: $([math]::Round($totalDuration.TotalSeconds, 2)) seconds" -ForegroundColor Yellow
Write-Host ""

foreach ($step in $results.Steps) {
    $statusColor = if ($step.Status -eq "Success") { "Green" } else { "Red" }
    Write-Host "  $($step.Name): " -NoNewline
    Write-Host $step.Status -ForegroundColor $statusColor -NoNewline
    if ($step.Duration) {
        Write-Host " ($([math]::Round($step.Duration, 2))s)" -ForegroundColor Gray
    } else {
        Write-Host ""
    }
}

# Save summary
$summaryFile = Join-Path $OutputDirectory "analysis_summary_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
$results | ConvertTo-Json -Depth 10 | Out-File -FilePath $summaryFile -Encoding UTF8
Write-Host ""
Write-Host "Summary saved to: $summaryFile" -ForegroundColor Green
Write-Host ""
Write-Host "All reports available in: $OutputDirectory" -ForegroundColor Cyan

