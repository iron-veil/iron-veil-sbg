# Comprehensive Manifest Generator
# Creates detailed file manifests with SHA256 hashes and metadata
# Uses proven PowerShell methods - tested and verified

param(
    [Parameter(Mandatory=$false)]
    [string]$TargetPath = "iron-veil-sbg-main",
    
    [Parameter(Mandatory=$false)]
    [string]$OutputFile = "file_manifest.json",
    
    [Parameter(Mandatory=$false)]
    [switch]$IncludeHash = $true,
    
    [Parameter(Mandatory=$false)]
    [switch]$IncludeMetadata = $true,
    
    [Parameter(Mandatory=$false)]
    [switch]$GenerateCSV = $true
)

Write-Host "=== Comprehensive Manifest Generator ===" -ForegroundColor Cyan
Write-Host "Target: $TargetPath" -ForegroundColor Yellow
Write-Host ""

if (-not (Test-Path $TargetPath)) {
    Write-Host "Error: Target path '$TargetPath' does not exist!" -ForegroundColor Red
    exit 1
}

# Function to format file size
function Format-FileSize {
    param([long]$Bytes)
    
    if ($Bytes -lt 1KB) { return "$Bytes B" }
    elseif ($Bytes -lt 1MB) { return "{0:N2} KB" -f ($Bytes / 1KB) }
    elseif ($Bytes -lt 1GB) { return "{0:N2} MB" -f ($Bytes / 1MB) }
    else { return "{0:N2} GB" -f ($Bytes / 1GB) }
}

# Collect all files
Write-Host "Scanning files..." -ForegroundColor Yellow
$allFiles = Get-ChildItem -Path $TargetPath -Recurse -File -ErrorAction SilentlyContinue
$basePath = (Resolve-Path $TargetPath).Path

$manifest = @{
    Generated = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
    Generator = "ManifestGenerator.ps1"
    Version = "1.0"
    TargetPath = $basePath
    TotalFiles = 0
    TotalSize = 0
    Files = @()
}

$fileIndex = 0
$totalSize = 0

foreach ($file in $allFiles) {
    $relativePath = $file.FullName.Replace($basePath + "\", "").Replace("\", "/")
    Write-Host "  Processing [$fileIndex]: $relativePath" -ForegroundColor Gray
    
    $fileEntry = @{
        Index = $fileIndex
        Name = $file.Name
        RelativePath = $relativePath
        FullPath = $file.FullName
        Size = $file.Length
        SizeFormatted = Format-FileSize -Bytes $file.Length
        Extension = $file.Extension
    }
    
    if ($IncludeMetadata) {
        $fileEntry.LastWriteTime = $file.LastWriteTime.ToString("yyyy-MM-ddTHH:mm:ss")
        $fileEntry.LastAccessTime = $file.LastAccessTime.ToString("yyyy-MM-ddTHH:mm:ss")
        $fileEntry.CreationTime = $file.CreationTime.ToString("yyyy-MM-ddTHH:mm:ss")
        $fileEntry.Attributes = $file.Attributes.ToString()
    }
    
    if ($IncludeHash) {
        try {
            $hash = (Get-FileHash -Path $file.FullName -Algorithm SHA256 -ErrorAction Stop).Hash.ToLower()
            $fileEntry.SHA256 = $hash
        } catch {
            Write-Host "    Warning: Could not compute hash - $($_.Exception.Message)" -ForegroundColor Yellow
            $fileEntry.SHA256 = "ERROR: $($_.Exception.Message)"
        }
    }
    
    $manifest.Files += $fileEntry
    $totalSize += $file.Length
    $fileIndex++
}

$manifest.TotalFiles = $fileIndex
$manifest.TotalSize = $totalSize
$manifest.TotalSizeFormatted = Format-FileSize -Bytes $totalSize

# Generate file type statistics
$extensions = $allFiles | Group-Object Extension | Sort-Object Count -Descending
$manifest.FileTypeStatistics = $extensions | ForEach-Object {
    $extSize = ($_.Group | Measure-Object -Property Length -Sum).Sum
    @{
        Extension = if ($_.Name) { $_.Name } else { "(no extension)" }
        Count = $_.Count
        TotalSize = $extSize
        TotalSizeFormatted = Format-FileSize -Bytes $extSize
    }
}

# Write JSON manifest
Write-Host ""
Write-Host "Generating JSON manifest..." -ForegroundColor Yellow
$jsonOutput = $manifest | ConvertTo-Json -Depth 10
$jsonOutput | Out-File -FilePath $OutputFile -Encoding UTF8
Write-Host "JSON manifest saved to: $OutputFile" -ForegroundColor Green

# Generate CSV if requested
if ($GenerateCSV) {
    $csvFile = $OutputFile -replace '\.json$', '.csv'
    Write-Host "Generating CSV manifest..." -ForegroundColor Yellow
    
    $csvData = $manifest.Files | Select-Object Index, Name, RelativePath, Size, SizeFormatted, Extension, SHA256, LastWriteTime
    $csvData | Export-Csv -Path $csvFile -NoTypeInformation -Encoding UTF8
    Write-Host "CSV manifest saved to: $csvFile" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== Manifest Generation Complete ===" -ForegroundColor Cyan
Write-Host "Files processed: $($manifest.TotalFiles)" -ForegroundColor Green
Write-Host "Total size: $($manifest.TotalSizeFormatted)" -ForegroundColor Green
Write-Host "File types: $($extensions.Count)" -ForegroundColor Green

