# Advanced File Integrity Verification System
# Comprehensive integrity checking with detailed reporting
# Uses proven PowerShell Get-FileHash method - tested and verified

param(
    [Parameter(Mandatory=$true)]
    [string]$InventoryFile = "Repository_file_inventory.csv",
    
    [Parameter(Mandatory=$false)]
    [string]$BasePath = ".",
    
    [Parameter(Mandatory=$false)]
    [string]$OutputDirectory = "verification_reports",
    
    [Parameter(Mandatory=$false)]
    [switch]$GenerateReport = $true,
    
    [Parameter(Mandatory=$false)]
    [switch]$StopOnError = $false
)

# Ensure output directory exists
if (-not (Test-Path $OutputDirectory)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
}

Write-Host "=== Advanced File Integrity Verification ===" -ForegroundColor Cyan
Write-Host "Inventory: $InventoryFile" -ForegroundColor Yellow
Write-Host "Base Path: $BasePath" -ForegroundColor Yellow
Write-Host ""

if (-not (Test-Path $InventoryFile)) {
    Write-Host "Error: Inventory file '$InventoryFile' not found!" -ForegroundColor Red
    exit 1
}

# Read inventory CSV - handle header with leading comma and map columns correctly
try {
    $csvContent = Get-Content -Path $InventoryFile
    $header = $csvContent[0]
    
    # Check if first column is empty (leading comma)
    if ($header -match '^,') {
        # Parse manually to handle column mapping
        $inventory = @()
        for ($i = 1; $i -lt $csvContent.Length; $i++) {
            $line = $csvContent[$i]
            if ([string]::IsNullOrWhiteSpace($line)) { continue }
            
            # Split by comma, handling quoted values
            $fields = $line -split ',(?=(?:[^"]*"[^"]*")*[^"]*$)'
            
            if ($fields.Count -ge 4) {
                $entry = [PSCustomObject]@{
                    Index = $fields[0].Trim()
                    path = $fields[1].Trim()
                    size_bytes = $fields[2].Trim()
                    sha256 = $fields[3].Trim()
                }
                $inventory += $entry
            }
        }
    } else {
        $inventory = Import-Csv -Path $InventoryFile -ErrorAction Stop
    }
    Write-Host "Loaded $($inventory.Count) entries from inventory" -ForegroundColor Green
} catch {
    Write-Host "Error reading inventory file: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Verification results
$results = @()
$verified = 0
$failed = 0
$missing = 0
$errors = 0
$startTime = Get-Date

foreach ($entry in $inventory) {
    # Skip empty rows
    if ([string]::IsNullOrWhiteSpace($entry.path)) {
        continue
    }
    
    $filePath = $entry.path
    # Handle paths that may already include base path
    if (-not $filePath.StartsWith($BasePath)) {
        $filePath = Join-Path $BasePath $filePath
    }
    
    $expectedHash = $entry.sha256.Trim().ToLower()
    $expectedSize = [long]$entry.size_bytes
    
    $result = [PSCustomObject]@{
        File = $entry.path
        Status = "Unknown"
        ExpectedHash = $expectedHash
        ActualHash = ""
        ExpectedSize = $expectedSize
        ActualSize = 0
        HashMatch = $false
        SizeMatch = $false
        Error = ""
        Timestamp = Get-Date
    }
    
    Write-Host "Checking: $($entry.path)" -NoNewline
    
    if (-not (Test-Path $filePath)) {
        Write-Host " [MISSING]" -ForegroundColor Red
        $result.Status = "MISSING"
        $result.Error = "File not found"
        $missing++
        $results += $result
        
        if ($StopOnError) {
            Write-Host "Stopping on error (missing file)" -ForegroundColor Red
            break
        }
        continue
    }
    
    try {
        # Get file information
        $fileInfo = Get-Item -Path $filePath -ErrorAction Stop
        $actualSize = $fileInfo.Length
        $result.ActualSize = $actualSize
        
        # Calculate hash using proven PowerShell method
        $hashObj = Get-FileHash -Path $filePath -Algorithm SHA256 -ErrorAction Stop
        $actualHash = $hashObj.Hash.ToLower()
        $result.ActualHash = $actualHash
        
        # Verify hash
        $hashMatch = ($actualHash -eq $expectedHash)
        $result.HashMatch = $hashMatch
        
        # Verify size
        $sizeMatch = ($actualSize -eq $expectedSize)
        $result.SizeMatch = $sizeMatch
        
        if ($hashMatch -and $sizeMatch) {
            Write-Host " [OK]" -ForegroundColor Green
            $result.Status = "VERIFIED"
            $verified++
        } elseif ($hashMatch -and -not $sizeMatch) {
            Write-Host " [SIZE MISMATCH]" -ForegroundColor Yellow
            Write-Host "   Expected: $expectedSize bytes, Actual: $actualSize bytes" -ForegroundColor Yellow
            $result.Status = "SIZE_MISMATCH"
            $result.Error = "Size mismatch: Expected $expectedSize, got $actualSize"
            $failed++
        } elseif (-not $hashMatch -and $sizeMatch) {
            Write-Host " [HASH MISMATCH]" -ForegroundColor Red
            Write-Host "   Expected: $expectedHash" -ForegroundColor Red
            Write-Host "   Actual:   $actualHash" -ForegroundColor Red
            $result.Status = "HASH_MISMATCH"
            $result.Error = "Hash mismatch"
            $failed++
        } else {
            Write-Host " [BOTH MISMATCH]" -ForegroundColor Red
            Write-Host "   Hash and size both mismatch" -ForegroundColor Red
            $result.Status = "BOTH_MISMATCH"
            $result.Error = "Hash and size both mismatch"
            $failed++
        }
        
    } catch {
        Write-Host " [ERROR: $($_.Exception.Message)]" -ForegroundColor Red
        $result.Status = "ERROR"
        $result.Error = $_.Exception.Message
        $errors++
        
        if ($StopOnError) {
            Write-Host "Stopping on error" -ForegroundColor Red
            break
        }
    }
    
    $results += $result
}

$endTime = Get-Date
$duration = $endTime - $startTime

# Summary
Write-Host ""
Write-Host "=== Verification Summary ===" -ForegroundColor Cyan
Write-Host "Verified:   $verified" -ForegroundColor Green
Write-Host "Failed:     $failed" -ForegroundColor $(if ($failed -eq 0) { "Green" } else { "Red" })
Write-Host "Missing:    $missing" -ForegroundColor $(if ($missing -eq 0) { "Green" } else { "Red" })
Write-Host "Errors:     $errors" -ForegroundColor $(if ($errors -eq 0) { "Green" } else { "Red" })
Write-Host "Total:      $($results.Count)" -ForegroundColor Cyan
Write-Host "Duration:   $($duration.TotalSeconds) seconds" -ForegroundColor Cyan

# Generate detailed report
if ($GenerateReport) {
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    
    # CSV Report
    $csvFile = Join-Path $OutputDirectory "verification_report_$timestamp.csv"
    $results | Export-Csv -Path $csvFile -NoTypeInformation -Encoding UTF8
    Write-Host ""
    Write-Host "CSV report saved to: $csvFile" -ForegroundColor Green
    
    # JSON Report
    $jsonReport = @{
        Generated = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
        InventoryFile = $InventoryFile
        BasePath = (Resolve-Path $BasePath).Path
        Summary = @{
            Total = $results.Count
            Verified = $verified
            Failed = $failed
            Missing = $missing
            Errors = $errors
            DurationSeconds = $duration.TotalSeconds
        }
        Results = $results
    }
    
    $jsonFile = Join-Path $OutputDirectory "verification_report_$timestamp.json"
    $jsonReport | ConvertTo-Json -Depth 10 | Out-File -FilePath $jsonFile -Encoding UTF8
    Write-Host "JSON report saved to: $jsonFile" -ForegroundColor Green
    
    # HTML Report
    $htmlReport = @"
<!DOCTYPE html>
<html>
<head>
    <title>File Integrity Verification Report - $(Get-Date -Format 'yyyy-MM-dd')</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1400px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        h2 { color: #34495e; margin-top: 30px; }
        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
        .stat-box { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }
        .stat-box.verified { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }
        .stat-box.failed { background: linear-gradient(135deg, #eb3349 0%, #f45c43 100%); }
        .stat-box.missing { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
        .stat-value { font-size: 36px; font-weight: bold; margin: 10px 0; }
        .stat-label { font-size: 14px; opacity: 0.9; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #34495e; color: white; position: sticky; top: 0; }
        tr:hover { background: #f5f5f5; }
        .status-verified { color: #27ae60; font-weight: bold; }
        .status-failed { color: #e74c3c; font-weight: bold; }
        .status-missing { color: #e67e22; font-weight: bold; }
        .status-error { color: #c0392b; font-weight: bold; }
        .hash { font-family: 'Consolas', monospace; font-size: 11px; }
        pre { background: #2c3e50; color: #ecf0f1; padding: 15px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1>File Integrity Verification Report</h1>
        <p><strong>Generated:</strong> $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")</p>
        <p><strong>Inventory File:</strong> $InventoryFile</p>
        <p><strong>Base Path:</strong> $BasePath</p>
        <p><strong>Duration:</strong> $([math]::Round($duration.TotalSeconds, 2)) seconds</p>
        
        <div class="summary">
            <div class="stat-box verified">
                <div class="stat-value">$verified</div>
                <div class="stat-label">Verified</div>
            </div>
            <div class="stat-box failed">
                <div class="stat-value">$failed</div>
                <div class="stat-label">Failed</div>
            </div>
            <div class="stat-box missing">
                <div class="stat-value">$missing</div>
                <div class="stat-label">Missing</div>
            </div>
            <div class="stat-box">
                <div class="stat-value">$errors</div>
                <div class="stat-label">Errors</div>
            </div>
        </div>
        
        <h2>Detailed Results</h2>
        <table>
            <tr>
                <th>File</th>
                <th>Status</th>
                <th>Expected Hash</th>
                <th>Actual Hash</th>
                <th>Expected Size</th>
                <th>Actual Size</th>
                <th>Error</th>
            </tr>
            $($results | ForEach-Object {
                $statusClass = "status-$($_.Status.ToLower().Replace('_', '-'))"
                "<tr>
                    <td>$($_.File)</td>
                    <td class='$statusClass'>$($_.Status)</td>
                    <td class='hash'>$($_.ExpectedHash)</td>
                    <td class='hash'>$($_.ActualHash)</td>
                    <td>$($_.ExpectedSize)</td>
                    <td>$($_.ActualSize)</td>
                    <td>$($_.Error)</td>
                </tr>"
            } | Out-String)
        </table>
    </div>
</body>
</html>
"@
    
    $htmlFile = Join-Path $OutputDirectory "verification_report_$timestamp.html"
    $htmlReport | Out-File -FilePath $htmlFile -Encoding UTF8
    Write-Host "HTML report saved to: $htmlFile" -ForegroundColor Green
}

# Exit with appropriate code
if ($failed -eq 0 -and $missing -eq 0 -and $errors -eq 0) {
    Write-Host ""
    Write-Host "All files verified successfully!" -ForegroundColor Green
    exit 0
} else {
    Write-Host ""
    Write-Host "Verification completed with issues." -ForegroundColor Yellow
    exit 1
}

