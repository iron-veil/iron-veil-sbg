# File System Analyzer Suite

Advanced file architecture mapping and integrity verification tools for GitHub repositories.

## 📁 Repository Structure

```
file-system-analyzer/
├── scripts/                    # PowerShell analysis tools
│   ├── FileArchitectureMapper.ps1
│   ├── AdvancedIntegrityVerifier.ps1
│   ├── ManifestGenerator.ps1
│   └── MasterFileSystemAnalyzer.ps1
│
├── docs/                       # Documentation
│   ├── COMPREHENSIVE_DOCUMENTATION.md
│   ├── QUICK_START.md
│   ├── README_FILE_INTEGRITY.md
│   └── FILE_LOCATIONS.md
│
├── data/                       # Inventory and reference files
│   ├── Repository_file_inventory.csv
│   └── Potential_implementation_files.csv
│
├── reports/                    # Generated reports (created when scripts run)
│
├── iron-veil-sbg-main/         # Example target directory
│   └── .github/
│       ├── ISSUE_TEMPLATE/
│       ├── workflows/
│       └── dependabot.yml
│
└── README.md                   # This file
```

## 🚀 Quick Start

### Prerequisites
- PowerShell 3.0 or higher
- Windows (or PowerShell Core on Linux/Mac)

### Run Complete Analysis
```powershell
cd scripts
.\MasterFileSystemAnalyzer.ps1 -TargetPath "..\iron-veil-sbg-main"
```

### Individual Tools

**Architecture Mapping:**
```powershell
cd scripts
.\FileArchitectureMapper.ps1 -TargetPath "..\iron-veil-sbg-main" -OutputFormat "HTML"
```

**Integrity Verification:**
```powershell
cd scripts
.\AdvancedIntegrityVerifier.ps1 -InventoryFile "..\data\Repository_file_inventory.csv" -BasePath ".."
```

**Generate Manifest:**
```powershell
cd scripts
.\ManifestGenerator.ps1 -TargetPath "..\iron-veil-sbg-main" -OutputFile "..\reports\manifest.json"
```

## 📊 What It Does

### File Architecture Mapping
- Scans directory structure recursively
- Generates visual tree representation
- Collects file metadata (size, dates, attributes)
- Calculates SHA256 hashes
- Provides statistics and file type distribution

### Integrity Verification
- Compares files against SHA256 hash inventory
- Verifies file sizes
- Detects modifications, corruption, and missing files
- Generates detailed reports with status codes

### Manifest Generation
- Creates complete file inventory
- Includes all metadata and hashes
- Exports to JSON and CSV formats

## 📝 CSV Inventory Format

The integrity verifier expects CSV files with this format:

```csv
,path,size_bytes,sha256
0,iron-veil-sbg-main/.editorconfig,186,9ff02b5f94e6cd180b657b690fe8a76936ea9f2f376e7bb0ce327130008b5b24
```

**Columns**:
- First column: Index (optional)
- `path`: Relative file path
- `size_bytes`: File size in bytes
- `sha256`: SHA256 hash (lowercase hex)

## 📚 Documentation

- **COMPREHENSIVE_DOCUMENTATION.md** - Complete reference guide
- **QUICK_START.md** - Quick start instructions
- **README_FILE_INTEGRITY.md** - File integrity concepts

## 🔧 Requirements

- PowerShell 3.0 or higher
- Read access to target directories
- Minimal disk space (text-based reports)

## ✨ Features

- ✅ **Proven Methods**: Uses built-in PowerShell cmdlets
- ✅ **Tested**: All scripts verified to work correctly
- ✅ **Comprehensive**: Multiple output formats and detailed reporting
- ✅ **Error Handling**: Robust error handling and recovery
- ✅ **Performance**: Optimized for large directories

## 📁 Output Locations

Reports are generated in the `reports/` directory:
- Architecture reports: `reports/architecture_*`
- Verification reports: `reports/verification_*`
- Manifests: `reports/*.json` and `reports/*.csv`

## 🔒 Security Notes

- SHA256 hashes are used for **integrity verification**, not encryption
- Hashes detect file modifications and tampering
- Store manifests securely for audit purposes
- Use in CI/CD pipelines for automated verification

## 📞 Usage Examples

### Verify Repository Integrity
```powershell
cd scripts
.\AdvancedIntegrityVerifier.ps1 -InventoryFile "..\data\Repository_file_inventory.csv" -BasePath ".." -OutputDirectory "..\reports"
```

### Generate Documentation
```powershell
cd scripts
.\FileArchitectureMapper.ps1 -TargetPath "..\iron-veil-sbg-main" -OutputFormat "All" -OutputDirectory "..\reports"
```

### Create New Manifest
```powershell
cd scripts
.\ManifestGenerator.ps1 -TargetPath "..\iron-veil-sbg-main" -OutputFile "..\reports\manifest.json" -IncludeHash -GenerateCSV
```

## 📄 License

These scripts are provided as-is for file system analysis and integrity verification purposes.

---

**Version**: 1.0  
**Last Updated**: 2025-11-26  
**Status**: ✅ Production Ready

