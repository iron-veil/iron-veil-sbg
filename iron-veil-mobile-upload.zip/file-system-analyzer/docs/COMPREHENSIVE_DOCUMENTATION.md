# Comprehensive File System Analysis Suite

## Overview

This suite provides advanced file architecture mapping, integrity verification, and manifest generation capabilities using proven PowerShell methods. All scripts have been tested and verified to work correctly.

## Tools Included

### 1. FileArchitectureMapper.ps1
**Purpose**: Generates comprehensive file structure analysis with visual tree representation

**Features**:
- Visual directory tree with ASCII characters
- File size statistics and formatting
- SHA256 hash generation (optional)
- Multiple output formats: Tree (TXT), JSON, CSV, HTML
- File type distribution analysis
- Detailed metadata collection

**Usage**:
```powershell
.\FileArchitectureMapper.ps1 -TargetPath "iron-veil-sbg-main" -OutputFormat "All" -IncludeHash
```

**Parameters**:
- `-TargetPath`: Directory to analyze (default: "iron-veil-sbg-main")
- `-OutputFormat`: Output format - All, Tree, JSON, CSV, HTML (default: "All")
- `-OutputDirectory`: Where to save reports (default: "architecture_reports")
- `-IncludeHash`: Include SHA256 hashes (default: $true)
- `-IncludeMetadata`: Include file metadata (default: $true)

**Output Files**:
- `architecture_tree_YYYYMMDD_HHMMSS.txt` - Visual tree structure
- `architecture_manifest_YYYYMMDD_HHMMSS.json` - Complete JSON manifest
- `architecture_inventory_YYYYMMDD_HHMMSS.csv` - CSV inventory
- `architecture_report_YYYYMMDD_HHMMSS.html` - HTML report with styling

---

### 2. AdvancedIntegrityVerifier.ps1
**Purpose**: Verifies file integrity against SHA256 hash inventory

**Features**:
- Compares current file hashes against inventory
- Verifies file sizes
- Detailed mismatch reporting
- Multiple output formats: CSV, JSON, HTML
- Performance metrics
- Error handling and recovery

**Usage**:
```powershell
.\AdvancedIntegrityVerifier.ps1 -InventoryFile "Repository_file_inventory.csv" -BasePath "." -GenerateReport
```

**Parameters**:
- `-InventoryFile`: CSV file with file paths and SHA256 hashes (required)
- `-BasePath`: Base directory for file resolution (default: ".")
- `-OutputDirectory`: Where to save reports (default: "verification_reports")
- `-GenerateReport`: Generate detailed reports (default: $true)
- `-StopOnError`: Stop on first error (default: $false)

**Output Files**:
- `verification_report_YYYYMMDD_HHMMSS.csv` - Detailed CSV results
- `verification_report_YYYYMMDD_HHMMSS.json` - JSON results with metadata
- `verification_report_YYYYMMDD_HHMMSS.html` - Visual HTML report

**Status Codes**:
- `VERIFIED`: Hash and size match
- `HASH_MISMATCH`: Hash doesn't match (file modified)
- `SIZE_MISMATCH`: Size doesn't match (possible corruption)
- `BOTH_MISMATCH`: Both hash and size mismatch
- `MISSING`: File not found
- `ERROR`: Error during verification

---

### 3. ManifestGenerator.ps1
**Purpose**: Creates comprehensive file manifests with metadata

**Features**:
- Complete file inventory with SHA256 hashes
- File metadata (dates, attributes, sizes)
- File type statistics
- JSON and CSV output formats
- Indexed file entries

**Usage**:
```powershell
.\ManifestGenerator.ps1 -TargetPath "iron-veil-sbg-main" -OutputFile "manifest.json" -IncludeHash -GenerateCSV
```

**Parameters**:
- `-TargetPath`: Directory to analyze (default: "iron-veil-sbg-main")
- `-OutputFile`: Output JSON file path (default: "file_manifest.json")
- `-IncludeHash`: Include SHA256 hashes (default: $true)
- `-IncludeMetadata`: Include file metadata (default: $true)
- `-GenerateCSV`: Also generate CSV file (default: $true)

**Output Files**:
- `[OutputFile].json` - Complete JSON manifest
- `[OutputFile].csv` - CSV version of manifest

---

### 4. MasterFileSystemAnalyzer.ps1
**Purpose**: Master script that runs all analysis tools in sequence

**Features**:
- Orchestrates all analysis tools
- Generates comprehensive summary
- Error handling and reporting
- Performance metrics
- Unified output directory

**Usage**:
```powershell
.\MasterFileSystemAnalyzer.ps1 -TargetPath "iron-veil-sbg-main" -InventoryFile "Repository_file_inventory.csv"
```

**Parameters**:
- `-TargetPath`: Directory to analyze (default: "iron-veil-sbg-main")
- `-InventoryFile`: CSV inventory file for verification (default: "Repository_file_inventory.csv")
- `-OutputDirectory`: Where to save all reports (default: "analysis_reports")
- `-RunArchitectureMapping`: Run architecture mapping (default: $true)
- `-RunIntegrityVerification`: Run integrity verification (default: $true)
- `-RunManifestGeneration`: Run manifest generation (default: $true)
- `-IncludeHash`: Include hashes in analysis (default: $true)

**Output**:
- All reports from individual tools
- `analysis_summary_YYYYMMDD_HHMMSS.json` - Summary of all operations

---

## CSV Inventory Format

The inventory CSV file should have the following format:

```csv
,path,size_bytes,sha256
0,iron-veil-sbg-main/.editorconfig,186,9ff02b5f94e6cd180b657b690fe8a76936ea9f2f376e7bb0ce327130008b5b24
1,iron-veil-sbg-main/.gitattributes,19,d60f352d0db1404c70afb4bb8b2ca3fd1c610572aa40720e8a0b7baa7885418c
```

**Columns**:
- First column: Index (optional, can be empty)
- `path`: Relative file path
- `size_bytes`: File size in bytes
- `sha256`: SHA256 hash in lowercase hexadecimal

**Note**: The script automatically handles leading commas in the header row.

---

## Technical Details

### Hash Algorithm
- **SHA256**: Used for all file integrity verification
- **Method**: PowerShell `Get-FileHash` cmdlet (proven, built-in)
- **Format**: Lowercase hexadecimal (64 characters)

### File Size Formatting
- Bytes: Displayed as "B"
- Kilobytes: Displayed as "KB" (2 decimal places)
- Megabytes: Displayed as "MB" (2 decimal places)
- Gigabytes: Displayed as "GB" (2 decimal places)

### Tree Characters
- Uses ASCII-safe characters: `+--` and `|` for tree structure
- Compatible with all PowerShell versions and encodings

### Error Handling
- All scripts include comprehensive error handling
- Errors are logged and reported without stopping execution
- Missing files are clearly identified
- Hash calculation errors are caught and reported

---

## Use Cases

### 1. Repository Integrity Verification
```powershell
# Verify all files match expected hashes
.\AdvancedIntegrityVerifier.ps1 -InventoryFile "Repository_file_inventory.csv" -BasePath "."
```

### 2. Complete Repository Analysis
```powershell
# Run full analysis suite
.\MasterFileSystemAnalyzer.ps1 -TargetPath "iron-veil-sbg-main"
```

### 3. Generate New Manifest
```powershell
# Create manifest for current repository state
.\ManifestGenerator.ps1 -TargetPath "iron-veil-sbg-main" -OutputFile "current_manifest.json"
```

### 4. Visual Architecture Documentation
```powershell
# Generate HTML report for documentation
.\FileArchitectureMapper.ps1 -TargetPath "iron-veil-sbg-main" -OutputFormat "HTML"
```

---

## Output Examples

### Tree Structure
```
+-- .github
    +-- ISSUE_TEMPLATE
    |   +-- bug_report.yml (2.18 KB) [SHA256: ef44e768...]
    |   +-- feature_request.yml (1.88 KB) [SHA256: 4b3cbbb0...]
    +-- workflows
    |   +-- codeql.yml (907 B) [SHA256: 56ba1808...]
```

### JSON Manifest
```json
{
  "Generated": "2025-11-26T22:15:05Z",
  "TargetPath": "C:\\Users\\Dylan\\Downloads\\iron-veil-sbg-main",
  "TotalFiles": 7,
  "TotalSize": 9190,
  "Files": [
    {
      "Index": 0,
      "Name": "bug_report.yml",
      "RelativePath": ".github/ISSUE_TEMPLATE/bug_report.yml",
      "SHA256": "ef44e768fb333ccde917cb84db62c7fb4ea292253c84f3c6534a068882417b2d",
      "Size": 2234,
      "SizeFormatted": "2.18 KB"
    }
  ]
}
```

---

## Requirements

- **PowerShell**: Version 3.0 or higher
- **Permissions**: Read access to target directories
- **Disk Space**: Minimal (reports are text-based)

---

## Best Practices

1. **Regular Verification**: Run integrity checks after significant changes
2. **Version Control**: Store inventory CSV files in version control
3. **Automation**: Integrate into CI/CD pipelines
4. **Documentation**: Keep manifests for historical reference
5. **Security**: Store hashes separately from files for tamper detection

---

## Troubleshooting

### CSV Header Warnings
If you see "WARNING: One or more headers were not specified":
- The script automatically handles this
- Ensure your CSV has proper column headers: `path`, `size_bytes`, `sha256`

### Hash Mismatches
- Expected if files have been modified
- Generate new manifest to update hashes
- Verify intentional changes vs. unauthorized modifications

### Missing Files
- Files listed in inventory but not found in directory
- Check file paths are relative to base path
- Verify files haven't been moved or deleted

### Performance
- Large directories may take time to process
- Hash calculation is the slowest operation
- Use `-IncludeHash:$false` for faster analysis

---

## Security Considerations

1. **SHA256 Hashes**: Used for integrity, not encryption
2. **File Verification**: Detects modifications and tampering
3. **Manifest Storage**: Store manifests securely
4. **Access Control**: Limit write access to inventory files
5. **Audit Trail**: Keep verification reports for compliance

---

## Version History

- **v1.0** (2025-11-26): Initial release
  - File architecture mapping
  - Integrity verification
  - Manifest generation
  - Master analyzer script

---

## Support

For issues or questions:
1. Check error messages in output
2. Review HTML reports for detailed information
3. Verify CSV format matches expected structure
4. Ensure PowerShell version compatibility

---

## License

These scripts are provided as-is for file system analysis and integrity verification purposes.

