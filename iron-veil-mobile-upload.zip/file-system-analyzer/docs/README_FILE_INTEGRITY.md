# File Integrity Verification Guide

## What are SHA256 Hashes?

The `Repository_file_inventory.csv` contains **SHA256 cryptographic hashes** for each file in the repository. These are **NOT encryption keys**, but rather **file integrity checksums** used for:

### Primary Uses:

1. **File Integrity Verification**
   - Detect if files have been modified, corrupted, or tampered with
   - Verify that files match their expected state
   - Ensure files haven't been accidentally changed

2. **Security Verification**
   - Verify file authenticity
   - Detect unauthorized modifications
   - Ensure files match the original repository state

3. **Repository Validation**
   - Verify complete repository state
   - Check for missing or modified files
   - Validate file sizes match expectations

## How SHA256 Works

- **SHA256** is a cryptographic hash function that produces a 64-character hexadecimal string
- Any change to a file (even a single byte) produces a completely different hash
- Same file content always produces the same hash
- It's a one-way function (cannot reverse the hash to get the original file)

## Using the Verification Tools

### 1. Verify File Integrity

Run the verification script to check all files against the inventory:

```powershell
.\verify_file_integrity.ps1 -InventoryFile "Repository_file_inventory.csv" -BasePath "iron-veil-sbg-main"
```

**Output:**
- ✅ **OK**: File hash and size match expected values
- ❌ **HASH MISMATCH**: File content has changed
- ⚠️ **SIZE MISMATCH**: File size doesn't match (may indicate corruption)
- ❌ **MISSING**: File doesn't exist

### 2. Generate New Hashes

Create a new inventory file with current file hashes:

```powershell
.\generate_file_hashes.ps1 -BasePath "iron-veil-sbg-main" -OutputFile "Repository_file_inventory_new.csv"
```

## Example Use Cases

### Verify Repository Integrity
```powershell
# After cloning or downloading a repository
.\verify_file_integrity.ps1
```

### Check Specific Files
```powershell
# Verify critical security files
$inventory = Import-Csv "Repository_file_inventory.csv"
$securityFiles = $inventory | Where-Object { $_.path -like "*SECURITY*" -or $_.path -like "*SECRET*" }
# Then verify each file individually
```

### Detect Tampering
```powershell
# Run verification and check exit code
.\verify_file_integrity.ps1
if ($LASTEXITCODE -ne 0) {
    Write-Host "WARNING: File integrity check failed!" -ForegroundColor Red
}
```

## Security Best Practices

1. **Store inventory securely**: Keep the CSV file in a secure location
2. **Verify regularly**: Run integrity checks periodically
3. **Version control**: Track the inventory CSV in version control
4. **Compare hashes**: Always verify hashes from trusted sources
5. **Automate checks**: Integrate verification into CI/CD pipelines

## Understanding the CSV Format

```csv
,path,size_bytes,sha256
0,iron-veil-sbg-main/.editorconfig,186,9ff02b5f94e6cd180b657b690fe8a76936ea9f2f376e7bb0ce327130008b5b24
```

- **Index**: Sequential number (0, 1, 2...)
- **path**: Relative file path from repository root
- **size_bytes**: File size in bytes
- **sha256**: 64-character hexadecimal SHA256 hash

## Limitations

- SHA256 hashes verify **file content**, not file permissions or metadata
- They don't provide encryption or access control
- They're one-way functions (cannot recover original content from hash)
- Hash collisions are theoretically possible but practically impossible

## Related Security Concepts

- **Digital Signatures**: Use private keys to sign hashes for authenticity
- **Checksums**: Simpler integrity checks (MD5, CRC32) - less secure than SHA256
- **SBOM (Software Bill of Materials)**: Lists all components and their hashes
- **Supply Chain Security**: Using hashes to verify software components

## Next Steps

1. Run `verify_file_integrity.ps1` to check current file state
2. Review any mismatches or missing files
3. Generate new inventory if files are intentionally modified
4. Integrate verification into your security workflow

