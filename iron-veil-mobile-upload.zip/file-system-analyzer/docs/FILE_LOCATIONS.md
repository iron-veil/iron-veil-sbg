# File Locations - Where Everything Is

## 📍 All Files Are In: `C:\Users\Dylan\Downloads`

### PowerShell Scripts (Main Tools)
```
C:\Users\Dylan\Downloads\FileArchitectureMapper.ps1
C:\Users\Dylan\Downloads\AdvancedIntegrityVerifier.ps1
C:\Users\Dylan\Downloads\ManifestGenerator.ps1
C:\Users\Dylan\Downloads\MasterFileSystemAnalyzer.ps1
```

### Data Files
```
C:\Users\Dylan\Downloads\Repository_file_inventory.csv
C:\Users\Dylan\Downloads\Potential_implementation_files.csv
```

### Target Directory (What We're Analyzing)
```
C:\Users\Dylan\Downloads\iron-veil-sbg-main\
```

### Output Directories (Reports Generated Here)
```
C:\Users\Dylan\Downloads\architecture_reports\
C:\Users\Dylan\Downloads\verification_reports\
C:\Users\Dylan\Downloads\analysis_reports\
```

### Documentation
```
C:\Users\Dylan\Downloads\README.md
C:\Users\Dylan\Downloads\COMPREHENSIVE_DOCUMENTATION.md
C:\Users\Dylan\Downloads\QUICK_START.md
C:\Users\Dylan\Downloads\README_FILE_INTEGRITY.md
```

## 🚀 How to Run

**From PowerShell, navigate to:**
```powershell
cd C:\Users\Dylan\Downloads
```

**Then run:**
```powershell
.\MasterFileSystemAnalyzer.ps1
```

## 📂 Current Directory Structure

```
C:\Users\Dylan\Downloads\
├── PowerShell Scripts (*.ps1)
│   ├── FileArchitectureMapper.ps1
│   ├── AdvancedIntegrityVerifier.ps1
│   ├── ManifestGenerator.ps1
│   └── MasterFileSystemAnalyzer.ps1
│
├── Target Directory
│   └── iron-veil-sbg-main\
│       └── .github\
│           ├── ISSUE_TEMPLATE\
│           ├── workflows\
│           └── dependabot.yml
│
├── CSV Files
│   ├── Repository_file_inventory.csv
│   └── Potential_implementation_files.csv
│
└── Output Directories (created when scripts run)
    ├── architecture_reports\
    ├── verification_reports\
    └── analysis_reports\
```

## ✅ Verification

To verify files exist, run:
```powershell
cd C:\Users\Dylan\Downloads
Get-ChildItem *.ps1
Get-ChildItem iron-veil-sbg-main -Recurse
```

