# Quick Start Guide

## Get Started in 3 Steps

### Step 1: Run Complete Analysis
```powershell
.\MasterFileSystemAnalyzer.ps1 -TargetPath "iron-veil-sbg-main"
```

This runs all tools and generates comprehensive reports in the `analysis_reports` directory.

### Step 2: View Reports
Open the HTML reports in your browser:
- `analysis_reports\architecture_report_*.html` - Visual file structure
- `analysis_reports\verification_report_*.html` - Integrity verification results

### Step 3: Review Results
- Check verification summary for any mismatches
- Review file architecture tree
- Examine JSON manifests for detailed metadata

## Individual Tool Usage

### Architecture Mapping Only
```powershell
.\FileArchitectureMapper.ps1 -TargetPath "iron-veil-sbg-main" -OutputFormat "HTML"
```

### Integrity Verification Only
```powershell
.\AdvancedIntegrityVerifier.ps1 -InventoryFile "Repository_file_inventory.csv" -BasePath "."
```

### Generate Manifest Only
```powershell
.\ManifestGenerator.ps1 -TargetPath "iron-veil-sbg-main" -OutputFile "manifest.json"
```

## Common Tasks

### Verify Repository Integrity
```powershell
.\AdvancedIntegrityVerifier.ps1 -InventoryFile "Repository_file_inventory.csv" -BasePath "." -GenerateReport
```

### Create New Manifest
```powershell
.\ManifestGenerator.ps1 -TargetPath "iron-veil-sbg-main" -OutputFile "new_manifest.json" -IncludeHash -GenerateCSV
```

### Generate Documentation
```powershell
.\FileArchitectureMapper.ps1 -TargetPath "iron-veil-sbg-main" -OutputFormat "All"
```

## Output Locations

- **Architecture Reports**: `architecture_reports\`
- **Verification Reports**: `verification_reports\`
- **Analysis Reports**: `analysis_reports\` (when using Master analyzer)

## Need Help?

See `COMPREHENSIVE_DOCUMENTATION.md` for detailed information.

