# Setup Instructions

## 📍 Location

All files are organized in: `C:\Users\Dylan\Downloads\file-system-analyzer\`

## 🚀 Quick Start

1. **Navigate to the scripts folder:**
   ```powershell
   cd C:\Users\Dylan\Downloads\file-system-analyzer\scripts
   ```

2. **Run the master analyzer:**
   ```powershell
   .\MasterFileSystemAnalyzer.ps1
   ```

3. **View reports:**
   Reports will be generated in the `reports/` folder.

## 📂 Folder Structure

```
file-system-analyzer/
├── scripts/              ← Run scripts from here
│   ├── FileArchitectureMapper.ps1
│   ├── AdvancedIntegrityVerifier.ps1
│   ├── ManifestGenerator.ps1
│   └── MasterFileSystemAnalyzer.ps1
│
├── docs/                 ← Documentation
├── data/                 ← CSV inventory files
├── reports/              ← Generated reports (created automatically)
├── iron-veil-sbg-main/   ← Example target directory
└── README.md
```

## ✅ Ready for GitHub

This folder is ready to import into GitHub:
- All scripts organized in `scripts/`
- Documentation in `docs/`
- Data files in `data/`
- `.gitignore` configured
- `README.md` included

Just navigate to the folder and run:
```powershell
git init
git add .
git commit -m "Initial commit"
```

